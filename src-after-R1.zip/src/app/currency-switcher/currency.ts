

export type EuropeanCurrency = 'EUR' | 'GBP';
export type NorthAmericanCurrency = "USD" | "CAD";
export type Currency = EuropeanCurrency | NorthAmericanCurrency;
