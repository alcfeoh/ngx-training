import { Component, inject } from '@angular/core';
import {NavigationComponent} from './navigation/navigation.component';
import {JumbotronComponent} from './jumbotron/jumbotron.component';
import {LicensePlateComponent} from './license-plate/license-plate.component';
import {DialogComponent} from './dialog/dialog.component';
import {HighlightDirective} from './highlight.directive';
import { AsyncPipe, DatePipe } from '@angular/common';
import { DateService } from './date.service';
import { LicensePlateService } from './license-plate.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    NavigationComponent,
    JumbotronComponent,
    LicensePlateComponent,
    DialogComponent,
    HighlightDirective,
    DatePipe,
    AsyncPipe
  ],
  templateUrl: "./app.component.html",
})
export class AppComponent {
  licensePlates$ = inject(LicensePlateService).getList();
  now = inject(DateService).getTodaysDate();
  showDialog = false;

}
