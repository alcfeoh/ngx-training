import { Component } from '@angular/core';
import {CALIFORNIA_PLATE, LICENSE_PLATES} from "./mock-data";
import {LicensePlate} from "./license-plate";
import {NavigationComponent} from './navigation/navigation.component';
import {JumbotronComponent} from './jumbotron/jumbotron.component';
import {LicensePlateComponent} from './license-plate/license-plate.component';
import {DialogComponent} from './dialog/dialog.component';
import {HighlightDirective} from './highlight.directive';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    NavigationComponent,
    JumbotronComponent,
    LicensePlateComponent,
    DialogComponent,
    HighlightDirective
  ],
  templateUrl: "./app.component.html",
})
export class AppComponent {
  licensePlates: LicensePlate[] = LICENSE_PLATES;

  showDialog = false;
}
