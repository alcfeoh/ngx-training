export interface LicensePlate {
  _id: string;
  onSale: boolean;
  picture: string;
  title: string;
  price: number;
  year: number;
  state: string;
  description: string;
}
