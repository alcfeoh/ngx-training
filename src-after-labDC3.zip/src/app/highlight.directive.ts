import {Directive, HostBinding, HostListener, Input} from '@angular/core';

@Directive({
  selector: '[appHighlight]',
  standalone: true,
})
export class HighlightDirective {

  @Input("appHighlight")
  color: string = "orange";

  @HostBinding('style.backgroundColor')
  backgroundColor: string = "";

  @HostListener('mouseover')
  onMouseOver(): void {
    this.backgroundColor = this.color;
  }

  @HostListener('mouseout')
  onMouseOut(): void {
    this.backgroundColor = "";
  }
}
