import { Component, inject } from '@angular/core';
import {CALIFORNIA_PLATE, LICENSE_PLATES} from "./mock-data";
import {LicensePlate} from "./license-plate";
import {NavigationComponent} from './navigation/navigation.component';
import {JumbotronComponent} from './jumbotron/jumbotron.component';
import {LicensePlateComponent} from './license-plate/license-plate.component';
import {DialogComponent} from './dialog/dialog.component';
import {HighlightDirective} from './highlight.directive';
import { DatePipe } from '@angular/common';
import { DateService } from './date.service';
import { LicensePlateService } from './license-plate.service';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    NavigationComponent,
    JumbotronComponent,
    LicensePlateComponent,
    DialogComponent,
    HighlightDirective,
    DatePipe
  ],
  templateUrl: "./app.component.html",
})
export class AppComponent {
  private plateService = inject(LicensePlateService);
  licensePlates: LicensePlate[] = this.plateService.getList();
  now = inject(DateService).getTodaysDate();
  showDialog = false;

}
