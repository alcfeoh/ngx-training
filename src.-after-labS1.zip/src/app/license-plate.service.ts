import { Injectable } from '@angular/core';
import { LicensePlate } from './license-plate';
import { LICENSE_PLATES } from './mock-data';

@Injectable({
  providedIn: 'root'
})
export class LicensePlateService {

  getList(): LicensePlate[] {
    return LICENSE_PLATES;
  }
}
