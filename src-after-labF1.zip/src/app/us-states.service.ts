import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface UsState {
  name: string;
  abbreviation: string;
}

@Injectable({
  providedIn: 'root'
})
export class UsStatesService {

  private http = inject(HttpClient);

  getUsStatesList(): Observable<UsState[]> {
    return this.http.get<UsState[]>("http://localhost:8000/states");
  }
}
