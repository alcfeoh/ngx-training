import {Component, Input} from '@angular/core';

@Component({
  selector: 'app-jumbotron',
  templateUrl: './jumbotron.component.html',
  standalone: true,
  styleUrls: ['./jumbotron.component.css']
})
export class JumbotronComponent {

  @Input({required: true})
  title!: string;
  // ! means "we know we're going to assign
  // a value later so don't warn us about the unused
  // variable"
  @Input()
  description? = "";
  // ? means that this variable is optional and may be
  // undefined

}
