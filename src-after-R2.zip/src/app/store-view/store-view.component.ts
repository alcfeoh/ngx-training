import { Component, inject } from '@angular/core';
import { JumbotronComponent } from "../jumbotron/jumbotron.component";
import { LicensePlateComponent } from "../license-plate/license-plate.component";
import { DialogComponent } from "../dialog/dialog.component";
import { AsyncPipe } from '@angular/common';
import { LicensePlateService } from '../license-plate.service';
import { HighlightDirective } from '../highlight.directive';

@Component({
  selector: 'app-store-view',
  standalone: true,
  imports: [
    JumbotronComponent, 
    LicensePlateComponent, 
    DialogComponent,
    AsyncPipe,
    HighlightDirective
  ],
  templateUrl: './store-view.component.html',
  styleUrl: './store-view.component.css'
})
export class StoreViewComponent {

  licensePlates$ = inject(LicensePlateService).getList();  
  showDialog = false;

}
